<?php
    $dbcon=mysqli_connect("localhost","root","","soen287");
?>