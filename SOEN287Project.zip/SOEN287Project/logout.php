<?php
session_start();
session_destroy();
header("location: P5.php");
?>